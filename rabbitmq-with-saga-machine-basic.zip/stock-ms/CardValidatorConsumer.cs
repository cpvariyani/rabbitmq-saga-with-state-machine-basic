﻿using MassTransit;
using rabbitmq_message.Events;
using System.Threading.Tasks;

namespace stock_ms
{
    public class CardValidatorConsumer :
       IConsumer<ICardValidatorEvent>
    {
        public async Task Consume(ConsumeContext<ICardValidatorEvent> context)
        {
            var data = context.Message;
        }
    }
}
